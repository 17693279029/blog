import{D as e,r}from"./index-490208dd.js";const t=e("menus",()=>({page:r(0)}));export{t as u};
