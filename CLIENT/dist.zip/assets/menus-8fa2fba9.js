import{D as e,r}from"./index-dd3a6795.js";const t=e("menus",()=>({page:r(0)}));export{t as u};
